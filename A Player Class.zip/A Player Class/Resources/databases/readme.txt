SplashKit can create SQLite databases for you, they will appear in this folder.
